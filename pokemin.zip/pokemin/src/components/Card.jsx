import React from "react";

function Card(props) {
  //   console.log(props.data, ">>>>>>>>>>>>>>>>>>>>>>>>>");
  return (
    <></>
    //   {data.map((item)=>{
    //       return(
    //         <div className="card" style={{ width: "18rem" }}>
    //         <img src={https://unpkg.com/pokeapi-sprites@2.0.2/sprites/pokemon/other/dream-world/{item.id}.svg} className="card-img-top" alt="..." />
    //         <div className="card-body">
    //           <h5 className="card-title"> title</h5>
    //         </div>
    //         <ul className="list-group list-group-flush">
    //           <li className="list-group-item">Id</li>
    //           <li className="list-group-item">Name</li>
    //         </ul>
    //         <div className="card-body">
    //           <button href="#" className="btn btn-success">
    //             Open Modal
    //           </button>
    //         </div>
    //       </div>
    //       )
    //   })}
  );
}

export default Card;
