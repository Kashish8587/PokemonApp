import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Home from "./components/Home";
function App() {
  return <>
   <Home/>
  </>;
}

export default App;
